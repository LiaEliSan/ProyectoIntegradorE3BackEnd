package com.babydevs.modelos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelosApplicationTests {

	@Test
	void contextLoads() {
	}

}
